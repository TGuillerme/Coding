for folder in Chain*
do
    prefix_folder=$(basename $folder _treesets)
    echo $prefix_folder

    #Get the right folder
    for file in ${folder}/*.treeset
    do
        #In the right folder get the right trees
        prefix_file=$(basename $file .treeset)
        echo "START ${prefix_file}" >> timer.txt
        date >> timer.txt
        sh TEM_TreeCmp_v0.2.sh ${prefix_folder}_treesets/M${prefix_folder}_L00F00C00.treeset ${file} 51 1000 ${prefix_file}
        echo "END $prefix" >> timer.txt
        date >> timer.txt
        echo "-----" >> timer.txt
    done
done
